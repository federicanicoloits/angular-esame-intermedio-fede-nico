export interface Property {
    ingredients: String;
    measures: String;
}
