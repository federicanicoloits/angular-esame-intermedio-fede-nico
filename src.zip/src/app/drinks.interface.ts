import { Drink } from "./drink.interface";
export interface Drinks {
    drinks: Array<Drink> | null;
}
